package com.cg.mra.ui;

import java.util.Scanner;
import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountNotFoundException;
import com.cg.mra.exceptions.InvalidMobileNumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args)  {
		int choice;

		AccountService services=new AccountServiceImpl();
		Account accountDetails=null;
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("\n1)Account Balance enquiry\n2)Recharge Account\n3)Exit\n");
			choice=sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("\nEnter Mobile Number:-");
				String mobileNo=sc.next();
				try {
					try {
						System.out.println(services.getAccountdetails(mobileNo));
					} catch (InvalidMobileNumberException e) {
						System.out.println("\nInvalid Mobile Number!");
					}
				} catch (AccountNotFoundException e) {
					System.out.println("\nGiven Account Id does not exist!");
				}
				break;
			case 2:
				System.out.println("\nEnter Mobile Number:-");
				String mobileNo2=sc.next();
				System.out.println("\nEnter Recharge amount:-");
				double rechargeAmount=sc.nextDouble();
				services.rechargeAccount(mobileNo2, rechargeAmount);
				System.out.println("\nAccount successfully recharged with "+rechargeAmount);
				System.out.println("\nUpdated balance in Account is:-"+services.rechargeAccount(mobileNo2, rechargeAmount));
				break;
			case 3:
				System.exit(0);
			}
		}
	}
}
