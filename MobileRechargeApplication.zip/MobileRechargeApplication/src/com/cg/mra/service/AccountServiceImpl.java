package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.AccountNotFoundException;
import com.cg.mra.exceptions.InvalidMobileNumberException;

public class AccountServiceImpl implements AccountService {
	private AccountDao accountDao=new AccountDaoImpl();   //Creating Generalized Object
	//Accepting Account Details
	@Override
	public Account getAccountdetails(String mobileNo) throws AccountNotFoundException, InvalidMobileNumberException {

		if(validateMobileNo(mobileNo)==true) {
			Account account=new Account();
			if(account==null)
				throw new AccountNotFoundException();
			else
				return accountDao.getAccountDetails(mobileNo);
		}
		return null;
	}
	//RechargeAmount Method
	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
	}
	//Checking MobileNumber length validity
	@Override
	public boolean validateMobileNo(String mobileNo) throws InvalidMobileNumberException {
		if(mobileNo==null || mobileNo.length()<10)
			throw new InvalidMobileNumberException("Invalid Mobile No.");
		return true;
	}
}
