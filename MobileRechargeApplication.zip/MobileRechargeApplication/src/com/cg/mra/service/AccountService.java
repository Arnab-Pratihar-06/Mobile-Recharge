package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountNotFoundException;
import com.cg.mra.exceptions.InvalidMobileNumberException;

public interface AccountService {
	Account getAccountdetails(String mobileNo) throws AccountNotFoundException, InvalidMobileNumberException;
	double rechargeAccount(String mobileNo,double rechargeAmount);
	boolean validateMobileNo(String mobileNo) throws InvalidMobileNumberException;
}
